self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e73c2ba0bfc02c77cf96bfbf49810daf",
    "url": "Engro_logo.jpg"
  },
  {
    "revision": "76adbd204f0b3c1fb03b3882308ea0f0",
    "url": "Jazz.jpg"
  },
  {
    "revision": "4805af2c6a24325ef4ad331773296a61",
    "url": "Logo.jpg"
  },
  {
    "revision": "32f64260ccc8cf8fec155ad5038c0bf5",
    "url": "TR.png"
  },
  {
    "revision": "48063b4493b77b68a92392e96727aeb3",
    "url": "TR1.jpg"
  },
  {
    "revision": "70394970a6603c125d564d94f79b3c78",
    "url": "TR11.jpg"
  },
  {
    "revision": "a9ee9e948334b4042e0db72c988ad883",
    "url": "Telenor.jpg"
  },
  {
    "revision": "7b084d84b8cd3e2cf53b4429ce1f2ec2",
    "url": "Zong.png"
  },
  {
    "revision": "c3b43b24567c673161a3",
    "url": "css/app.d9497c73.css"
  },
  {
    "revision": "5bc954538d9746ca2446",
    "url": "css/chunk-vendors.f092c4a3.css"
  },
  {
    "revision": "13fb2230db90119b82e867ab8b65f9a0",
    "url": "engro-logo.jpg"
  },
  {
    "revision": "7a513f287cf3cf242906676fac29e34c",
    "url": "img/Critical.7a513f28.jpg"
  },
  {
    "revision": "1ce4ebb0401098c45829d41e329d03a8",
    "url": "img/Normal.1ce4ebb0.png"
  },
  {
    "revision": "3c98970b4f41a26741570780e4dd5d25",
    "url": "img/Shutdown.3c98970b.png"
  },
  {
    "revision": "63a7d78d42c33b94fc7b957524795cac",
    "url": "img/logo.63a7d78d.svg"
  },
  {
    "revision": "82b9c7a5a3f405032b1db71a25f67021",
    "url": "img/logo.82b9c7a5.png"
  },
  {
    "revision": "7ce6c3e09697ed890bc38dcfbd6fd61c",
    "url": "index.html"
  },
  {
    "revision": "e09c7a790757757139ba",
    "url": "js/about.ce7d3a32.js"
  },
  {
    "revision": "c3b43b24567c673161a3",
    "url": "js/app.ae8543d6.js"
  },
  {
    "revision": "5bc954538d9746ca2446",
    "url": "js/chunk-vendors.78e64ed2.js"
  },
  {
    "revision": "d246407ac4d230b530feaa3aa565ce55",
    "url": "manifest.json"
  },
  {
    "revision": "3a69a461549b182809541ba3a63725a2",
    "url": "print.jpg"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  },
  {
    "revision": "bd9552f05701dd5b1235e50e89925884",
    "url": "site_tower.jpeg"
  },
  {
    "revision": "1b4a9394f7503a302ed55335726fff2b",
    "url": "tower1_logo.jpg"
  },
  {
    "revision": "34ba58b05b7d199f415fd71c49dc63ac",
    "url": "tower_icon.png"
  },
  {
    "revision": "33f91252553b5f0f1012d43de3799f40",
    "url": "tower_icon1.png"
  },
  {
    "revision": "f7da0d3124d11263460f426c9828a134",
    "url": "tower_icon2.png"
  }
]);